import { createClient } from "@supabase/supabase-js";

// ── Supabase client ──
export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
export const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY
  || import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

if(!SUPABASE_URL || !SUPABASE_KEY){
  console.error("Thieu bien moi truong Supabase!", {url: SUPABASE_URL, key: !!SUPABASE_KEY});
}

export const supabase = createClient(SUPABASE_URL || "", SUPABASE_KEY || "", {
  auth: { persistSession: false }
});
